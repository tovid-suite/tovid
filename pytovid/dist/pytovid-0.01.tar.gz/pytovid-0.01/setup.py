#! /usr/bin/env python

from distutils.core import setup

setup(  name='pytovid',
        author='Eric Pierce',
        author_email='wapcaplet@users.sf.net',
        version='0.01',
        url='http://tovid.org/',
        packages=['libtovid'],
        )


